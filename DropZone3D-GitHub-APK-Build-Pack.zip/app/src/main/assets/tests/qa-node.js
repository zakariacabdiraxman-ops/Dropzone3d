// Offline QA for the game's actual JavaScript logic. A WebGL mock executes the
// renderer setup and draw submission, but does not replace a visual GPU test.
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '..', 'game.js'), 'utf8');
const listeners = new Map();
const raf = [];
let drawCalls = 0;
const noOp = () => {};
function element(id) {
  const classes = new Set();
  return {
    id, textContent: '', innerHTML: '', style: {}, width: id === 'map' ? 180 : 0,
    height: id === 'map' ? 180 : 0, clientWidth: id === 'world' ? 1280 : 180,
    clientHeight: id === 'world' ? 720 : 180, offsetWidth: 20,
    classList: {
      add: (...v) => v.forEach(x => classes.add(x)),
      remove: (...v) => v.forEach(x => classes.delete(x)),
      contains: v => classes.has(v),
      toggle: (v, force) => { const on = force === undefined ? !classes.has(v) : force; on ? classes.add(v) : classes.delete(v); return on; }
    },
    addEventListener: (name, cb) => listeners.set(`${id}:${name}`, cb),
    querySelector: () => ({ textContent: '' }),
    requestPointerLock: noOp,
    getBoundingClientRect: () => ({left:0,top:0,width:122,height:122}),
    setPointerCapture: noOp,
    getContext(type) { return type === '2d' ? ctx2d : gl; }
  };
}
const ctx2d = new Proxy({}, {get:(_,key)=>key==='measureText'?()=>({width:0}):noOp,set:()=>true});
const elements = new Map();
const getElementById = id => { if (!elements.has(id)) elements.set(id, element(id)); return elements.get(id); };
const constants = {VERTEX_SHADER:1,FRAGMENT_SHADER:2,COMPILE_STATUS:3,LINK_STATUS:4,ARRAY_BUFFER:5,DYNAMIC_DRAW:6,STATIC_DRAW:7,FLOAT:8,DEPTH_TEST:9,LEQUAL:10,COLOR_BUFFER_BIT:11,DEPTH_BUFFER_BIT:12,TRIANGLES:13,LINES:14,VERSION:15};
const gl = new Proxy({
  ...constants,createShader:type=>({type}),createProgram:()=>({}),createBuffer:()=>({}),
  getShaderParameter:()=>true,getProgramParameter:()=>true,getShaderInfoLog:()=>'',getProgramInfoLog:()=>'',
  getAttribLocation:(_,name)=>({aPosition:0,aNormal:1,aColor:2}[name]??0),getUniformLocation:(_,name)=>name,
  getParameter:p=>p===constants.VERSION?'WebGL 1.0 (Node mock)':0,
  drawArrays:()=>{drawCalls++;},shaderSource:noOp,compileShader:noOp,attachShader:noOp,linkProgram:noOp,
  useProgram:noOp,bindBuffer:noOp,bufferData:noOp,enableVertexAttribArray:noOp,vertexAttribPointer:noOp,
  uniformMatrix4fv:noOp,uniform3f:noOp,viewport:noOp,enable:noOp,disable:noOp,depthFunc:noOp,
  clearColor:noOp,clear:noOp,depthMask:noOp
},{get:(o,k)=>k in o?o[k]:noOp});
const document = {getElementById,pointerLockElement:null,addEventListener:(n,cb)=>listeners.set(`document:${n}`,cb),exitPointerLock:noOp,createElement:tag=>element(tag)};
const window = {devicePixelRatio:1,addEventListener:(n,cb)=>listeners.set(`window:${n}`,cb),requestAnimationFrame:cb=>{raf.push(cb);return raf.length;}};
const sandbox = {document,window,gl,location:{search:''},URLSearchParams,console,Math,Float32Array,Uint8Array,Array,Set,Map,performance:{now:()=>100},requestAnimationFrame:cb=>{raf.push(cb);return raf.length;},setTimeout,clearTimeout};
vm.runInNewContext(source,sandbox,{filename:'game.js',timeout:10000});
const api=window.__DROPZONE_TEST__;
if(!api)throw new Error('Game did not expose QA interface');
const firstFrame=raf.shift();if(firstFrame)firstFrame(16.7);
const results=[];
function check(name,fn){try{const ok=!!fn();results.push({name,ok});}catch(e){results.push({name,ok:false,error:e.message});}}

check('WebGL setup, generated island mesh, and draw submission (mock context)',()=>api.glVersion().includes('WebGL')&&api.meshVertices()>10000&&api.frameCount()>0&&drawCalls>0);
api.start();
check('Deployment initializes the player and nine rival operatives',()=>api.state()==='playing'&&api.player().hp===100&&Array.from({length:9},(_,i)=>api.bot(i)).every(b=>b&&b.alive));
api.setPlayer(0,0,Math.PI);
const p0=api.player();api.setKey('KeyW',true);api.update(.3);api.setKey('KeyW',false);const p1=api.player();
api.setKey('ShiftLeft',true);api.setKey('KeyW',true);api.update(.2);api.setKey('ShiftLeft',false);api.setKey('KeyW',false);const p2=api.player();
check('Keyboard movement works and sprint consumes stamina',()=>p1.z>p0.z&&p2.stamina<p1.stamina);
api.setPlayer(0,0,Math.PI);api.switchWeapon(1);api.positionBot(0,0,8);api.fire();const shotgunHit=api.bot(0),shotgunShot=api.player();api.setReload(.02);api.update(.03);const shotgunReload=api.player();
check('Weapon switching equips the shotgun; shot damages target and reload restores shell',()=>shotgunHit.hp<100&&shotgunShot.weapon===1&&shotgunShot.ammo===5&&shotgunReload.ammo===6&&shotgunReload.reserve===35);
api.update(.8);api.switchWeapon(0);api.positionBot(1,0,7);api.fire();const rifleShot=api.player();api.setReload(.02);api.update(.03);const rifleReload=api.player();
check('Assault rifle retains its own magazine and reserve when switched back',()=>rifleShot.weapon===0&&rifleShot.ammo===29&&rifleReload.ammo===30&&rifleReload.reserve===149);
api.setPlayer(0,0,Math.PI);api.damage(30);const hurt=api.player().hp;api.addPickup('med',0,0);api.collect();const healed=api.player().hp;const reserve=api.player().reserve;api.addPickup('ammo',0,0);api.collect();
check('Medkit pickup restores health and ammo crate resupplies both weapons',()=>hurt<100&&healed===100&&api.player().reserve===reserve+45&&api.pickups()>=0);
check('Mobile joystick, aim-pad, fire, jump, reload, and swap events are wired',()=>['move-stick:pointerdown','move-stick:pointermove','aim-pad:pointermove','touch-fire:pointerdown','touch-jump:pointerdown','touch-reload:pointerdown','touch-swap:pointerdown'].every(k=>listeners.has(k)));
api.setElapsed(210);api.update(.02);const contracted=api.player().zone<73;api.forceVictory();const won=api.state()==='won';api.restart();const restarted=api.state()==='playing';api.forceDefeat();const lost=api.state()==='lost';
check('Safe-zone contraction, victory, defeat, and restart transitions',()=>contracted&&won&&restarted&&lost);

for(let i=0;i<results.length;i++)console.log(`${results[i].ok?'PASS':'FAIL'} — ${i+1}/${results.length} — ${results[i].name}${results[i].error?` (${results[i].error})`:''}`);
console.log(`\nRESULT: ${results.filter(r=>r.ok).length}/${results.length} PASSED`);
if(results.some(r=>!r.ok))process.exitCode=1;
