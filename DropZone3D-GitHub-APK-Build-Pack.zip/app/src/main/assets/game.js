(() => {
'use strict';
const canvas = document.getElementById('world');
const gl = canvas.getContext('webgl', {antialias:true, alpha:false, powerPreference:'high-performance'});
if (!gl) {
  document.getElementById('loading').textContent = 'WEBGL IS NOT AVAILABLE IN THIS BROWSER';
  throw new Error('WebGL is unavailable');
}
const $ = id => document.getElementById(id);
const ui = {
  hud:$('hud'), start:$('start'), pause:$('pause'), end:$('end'), deploy:$('deploy'), resume:$('resume'), restart:$('restart'), again:$('again'),
  alive:$('alive'), kills:$('kills'), timer:$('timer'), hpLabel:$('hp-label'), hpBar:$('hp-bar'), armorLabel:$('armor-label'), armorBar:$('armor-bar'),
  ammo:$('ammo'), reserve:$('reserve'), reload:$('reload'), zone:$('zone-warning'), map:$('map'), hit:$('hit'), hurt:$('hurt'), toast:$('toast'),
  staminaBar:$('stamina-bar'), weaponName:$('weapon-name'), weaponCode:$('weapon-code'), weaponMeta:$('weapon-meta'),
  endTitle:$('end-title'), endCopy:$('end-copy'), finalKills:$('final-kills')
};

const VERT = `
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute vec3 aColor;
uniform mat4 uVP;
uniform vec3 uCamera;
varying vec3 vColor;
varying float vLight;
varying float vFog;
void main(){
  vec4 clip = uVP * vec4(aPosition, 1.0);
  gl_Position = clip;
  vec3 n = normalize(aNormal);
  vec3 sun = normalize(vec3(-0.42, 0.86, 0.31));
  vLight = 0.38 + max(dot(n, sun), 0.0) * 0.78;
  vColor = aColor;
  vFog = distance(aPosition, uCamera);
}`;
const FRAG = `
precision mediump float;
varying vec3 vColor;
varying float vLight;
varying float vFog;
uniform vec3 uFogColor;
void main(){
  vec3 lit = vColor * vLight;
  float fog = smoothstep(82.0, 155.0, vFog);
  gl_FragColor = vec4(mix(lit, uFogColor, fog), 1.0);
}`;
function shader(type, source) {
  const s = gl.createShader(type); gl.shaderSource(s, source); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
  return s;
}
const program = gl.createProgram();
gl.attachShader(program, shader(gl.VERTEX_SHADER, VERT));
gl.attachShader(program, shader(gl.FRAGMENT_SHADER, FRAG));
gl.linkProgram(program);
if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program));
gl.useProgram(program);
const loc = {
  pos:gl.getAttribLocation(program,'aPosition'), normal:gl.getAttribLocation(program,'aNormal'), color:gl.getAttribLocation(program,'aColor'),
  vp:gl.getUniformLocation(program,'uVP'), camera:gl.getUniformLocation(program,'uCamera'), fog:gl.getUniformLocation(program,'uFogColor')
};
const staticBuffer = gl.createBuffer(), dynamicBuffer = gl.createBuffer(), lineBuffer = gl.createBuffer();
const STRIDE = 9 * 4;
function bindAttributes(buffer) {
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.enableVertexAttribArray(loc.pos); gl.vertexAttribPointer(loc.pos,3,gl.FLOAT,false,STRIDE,0);
  gl.enableVertexAttribArray(loc.normal); gl.vertexAttribPointer(loc.normal,3,gl.FLOAT,false,STRIDE,12);
  gl.enableVertexAttribArray(loc.color); gl.vertexAttribPointer(loc.color,3,gl.FLOAT,false,STRIDE,24);
}
function bindBuffer(buffer, data) { bindAttributes(buffer); gl.bufferData(gl.ARRAY_BUFFER, data, gl.DYNAMIC_DRAW); }

const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,t)=>a+(b-a)*t;
const vec=(x,y,z)=>[x,y,z];
const normalize=v=>{const n=Math.hypot(v[0],v[1],v[2])||1;return [v[0]/n,v[1]/n,v[2]/n];};
function perspective(fovy,aspect,near,far){const f=1/Math.tan(fovy/2),nf=1/(near-far);return new Float32Array([f/aspect,0,0,0,0,f,0,0,0,0,(far+near)*nf,-1,0,0,2*far*near*nf,0]);}
function lookAt(eye,target,up=[0,1,0]){
  const z=normalize([eye[0]-target[0],eye[1]-target[1],eye[2]-target[2]]);
  const x=normalize([up[1]*z[2]-up[2]*z[1],up[2]*z[0]-up[0]*z[2],up[0]*z[1]-up[1]*z[0]]);
  const y=[z[1]*x[2]-z[2]*x[1],z[2]*x[0]-z[0]*x[2],z[0]*x[1]-z[1]*x[0]];
  return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-(x[0]*eye[0]+x[1]*eye[1]+x[2]*eye[2]),-(y[0]*eye[0]+y[1]*eye[1]+y[2]*eye[2]),-(z[0]*eye[0]+z[1]*eye[1]+z[2]*eye[2]),1]);
}
function multiply(a,b){const o=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3];return o;}

function color(hex){return [((hex>>16)&255)/255,((hex>>8)&255)/255,(hex&255)/255];}
function seeded(seed){let s=seed>>>0;return ()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
function tri(out,a,b,c,col,center=null){
  let ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
  let nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
  if(center && nx*(a[0]+b[0]+c[0]-3*center[0])+ny*(a[1]+b[1]+c[1]-3*center[1])+nz*(a[2]+b[2]+c[2]-3*center[2])<0){const t=b;b=c;c=t;nx=-nx;ny=-ny;nz=-nz;}
  const n=Math.hypot(nx,ny,nz)||1;nx/=n;ny/=n;nz/=n;
  for(const p of [a,b,c])out.push(p[0],p[1],p[2],nx,ny,nz,col[0],col[1],col[2]);
}
function quad(out,a,b,c,d,col){tri(out,a,b,c,col);tri(out,a,c,d,col);}
function rotatePoint(x,y,z,cx,cy,cz,yaw){const co=Math.cos(yaw),si=Math.sin(yaw);return [cx+x*co+z*si,cy+y,cz-x*si+z*co];}
function box(out,x,y,z,w,h,d,hex,yaw=0){
  const hx=w/2,hy=h/2,hz=d/2, c=color(hex),p=(a,b,cc)=>rotatePoint(a,b,cc,x,y,z,yaw);
  const a=p(-hx,-hy,-hz),b=p(hx,-hy,-hz),cc=p(hx,hy,-hz),dd=p(-hx,hy,-hz),e=p(-hx,-hy,hz),f=p(hx,-hy,hz),g=p(hx,hy,hz),hh=p(-hx,hy,hz);
  quad(out,e,f,g,hh,c); quad(out,b,a,dd,cc,c); quad(out,f,b,cc,g,c); quad(out,a,e,hh,dd,c); quad(out,hh,g,cc,dd,c); quad(out,a,b,f,e,c);
}
function sphere(out,x,y,z,rx,ry,rz,hex,segments=9,rings=6){
  const c=color(hex),center=[x,y,z];
  for(let r=0;r<rings;r++){const p0=-Math.PI/2+Math.PI*r/rings,p1=-Math.PI/2+Math.PI*(r+1)/rings;
    for(let s=0;s<segments;s++){const t0=2*Math.PI*s/segments,t1=2*Math.PI*(s+1)/segments;
      const P=(p,t)=>[x+rx*Math.cos(p)*Math.cos(t),y+ry*Math.sin(p),z+rz*Math.cos(p)*Math.sin(t)];
      const a=P(p0,t0),b=P(p0,t1),cc=P(p1,t1),d=P(p1,t0);tri(out,a,b,cc,c,center);tri(out,a,cc,d,c,center);
    }
  }
}
function cylinder(out,x,y,z,r,h,hex,segments=9){
  const c=color(hex),top=y+h/2,bot=y-h/2;
  for(let i=0;i<segments;i++){const a=i*2*Math.PI/segments,b=(i+1)*2*Math.PI/segments;
    const p1=[x+Math.cos(a)*r,bot,z+Math.sin(a)*r],p2=[x+Math.cos(b)*r,bot,z+Math.sin(b)*r],p3=[x+Math.cos(b)*r,top,z+Math.sin(b)*r],p4=[x+Math.cos(a)*r,top,z+Math.sin(a)*r];
    tri(out,p1,p2,p3,c,[x,y,z]);tri(out,p1,p3,p4,c,[x,y,z]);tri(out,[x,top,z],p4,p3,c,[x,top,z]);tri(out,[x,bot,z],p2,p1,c,[x,bot,z]);
  }
}
function cone(out,x,y,z,r,h,hex,segments=9){
  const c=color(hex),apex=[x,y+h,z],center=[x,y,z];
  for(let i=0;i<segments;i++){const a=i*2*Math.PI/segments,b=(i+1)*2*Math.PI/segments,p1=[x+Math.cos(a)*r,y,z+Math.sin(a)*r],p2=[x+Math.cos(b)*r,y,z+Math.sin(b)*r];tri(out,p1,p2,apex,c,center);tri(out,[x,y,z],p2,p1,c,[x,y,z-0.01]);}
}
function groundY(x,z){const dist=Math.hypot(x,z);const n=Math.sin(x*.085)*Math.cos(z*.071)*.62+Math.sin((x+z)*.043)*.48+Math.cos(z*.12-x*.04)*.18;return -0.2+Math.max(0,1-dist/92)*n;}
const staticData=[];
const obstacleList=[];
function addGround(){
  const R=88,N=64,step=R*2/N;
  // surrounding sea
  box(staticData,0,-1.55,0,250,.25,250,0x315d68);
  // beach-colored island shelf
  const bands=[0x9eaa70,0x829a58,0x6c8950];
  for(let iz=0;iz<N;iz++)for(let ix=0;ix<N;ix++){
    const x0=-R+ix*step,z0=-R+iz*step,x1=x0+step,z1=z0+step;
    const pts=[[x0,z0],[x1,z0],[x1,z1],[x0,z1]].map(([x,z])=>[x,groundY(x,z),z]);
    const dist=Math.hypot((x0+x1)/2,(z0+z1)/2),rnd=(Math.sin(ix*12.989+iz*78.233)*43758.5453)%1;
    let col=dist>81?bands[0]:dist>69?bands[1]:bands[2];
    if(rnd>.78)col=dist>81?0xb1ad7b:0x748d4f;
    const c=color(col);quad(staticData,pts[0],pts[3],pts[2],pts[1],c);
  }
}
function addRoad(x,z,w,d,yaw=0){
  const y=groundY(x,z)+.035;box(staticData,x,y,z,w,.045,d,0x575d56,yaw);
  const count=Math.max(2,Math.floor((yaw===0?d:w)/5));
  for(let i=0;i<count;i++){const t=(i/(count-1)-.5)*(yaw===0?d:w);const px=x+(yaw===0?0:t),pz=z+(yaw===0?t:0);box(staticData,px,y+.03,pz,.12,.014,1.25,0xd5c99c,yaw);}
}
function addBuilding(x,z,w,d,h,wall,roof,angle=0){
  const y=groundY(x,z);box(staticData,x,y+h/2,z,w,h,d,wall,angle);box(staticData,x,y+h+.16,z,w+.38,.32,d+.38,roof,angle);
  // front windows and door
  for(let k=-1;k<=1;k++){
    const wx=x+k*w*.27, wz=z-d/2-.015;
    box(staticData,wx,y+h*.57,wz,.68,.82,.035,0x243c42,angle);
    box(staticData,wx,y+h*.57,wz-.026,.055,.88,.02,0x92b6b4,angle);
  }
  box(staticData,x,y+.95,z-d/2-.035,.88,1.85,.07,0x403e34,angle);
  // roof vents
  box(staticData,x+w*.29,y+h+.43,z+d*.18,.48,.24,.48,0x414b48,angle);
  obstacleList.push({x,z,w:w+1.1,d:d+1.1,yaw:angle});
}
function buildWorld(){
  addGround();
  addRoad(0,0,11,150);addRoad(-31,7,66,8,Math.PI/2);addRoad(28,-27,62,7,Math.PI/2);
  // runway / warehouse complex
  addBuilding(-27,-23,18,13,5.4,0x777e72,0x39443e,-.05);
  addBuilding(-48,19,13,11,4.2,0x8b8068,0x48534b,.08);
  addBuilding(34,15,16,13,5.2,0x807b6a,0x424a40,-.18);
  addBuilding(48,-34,14,12,4.4,0x8d8873,0x43504a,.1);
  addBuilding(-5,43,17,12,4.9,0x8e8a75,0x3c4a42,.04);
  addBuilding(-51,-43,12,10,4.1,0x877b69,0x3d4941,.12);
  addBuilding(3,-54,18,13,5.1,0x85836f,0x48534b,-.03);
  addBuilding(54,42,12,10,4.2,0x8c816b,0x46514a,-.2);
  // central control tower
  const ty=groundY(8,3);box(staticData,8,ty+3.9,3,7,7.8,7,0x777e73);box(staticData,8,ty+8,3,8.2,.5,8.2,0x343f3a);box(staticData,8,ty+6,3-3.57,3.8,1.2,.08,0x273a40);obstacleList.push({x:8,z:3,w:9,d:9,yaw:0});
  // shipping containers, walls, crates
  const containers=[[-13,-7,0xb4533d],[13,-15,0x3d7080],[29,1,0xa36a35],[-39,-4,0x536f58],[40,30,0x9b4b3c],[-16,28,0x496777]];
  for(const [x,z,c] of containers){const y=groundY(x,z);box(staticData,x,y+1.35,z,9,2.7,2.8,c,Math.sin(x)*.2);for(let k=-3;k<=3;k++)box(staticData,x+k*1.2,y+1.36,z-1.43,.045,2.4,.04,0x263e40);obstacleList.push({x,z,w:10,d:4,yaw:0});}
  const rng=seeded(89321);
  // forest ring
  for(let i=0;i<108;i++){
    const a=rng()*Math.PI*2,r=22+rng()*56,x=Math.cos(a)*r,z=Math.sin(a)*r;
    if(Math.hypot(x,z)>80)continue;
    if(obstacleList.some(o=>Math.abs(x-o.x)<o.w/2+2&&Math.abs(z-o.z)<o.d/2+2))continue;
    const y=groundY(x,z),s=.8+rng()*.85;
    cylinder(staticData,x,y+s*.8,z,.19*s,1.6*s,0x584a35,7);
    cone(staticData,x,y+1.0*s,z,1.05*s,2.2*s, rng()>.5?0x31583c:0x426d43,8);
    cone(staticData,x,y+1.9*s,z,.74*s,1.7*s,0x4e7846,8);
  }
  // rocks and low cover
  for(let i=0;i<52;i++){
    const a=rng()*6.28,r=12+rng()*67,x=Math.cos(a)*r,z=Math.sin(a)*r;
    if(obstacleList.some(o=>Math.abs(x-o.x)<o.w/2+1.5&&Math.abs(z-o.z)<o.d/2+1.5))continue;
    const y=groundY(x,z);sphere(staticData,x,y+.36,z,.55+rng()*.55,.4+rng()*.35,.5+rng()*.6,0x777b6e,7,4);
  }
  // sandbag arcs and crates around compounds
  for(const [x,z] of [[-12,-12],[19,9],[-34,14],[42,-27],[0,31]]){
    for(let i=0;i<5;i++){const a=i*.32-.64,px=x+Math.cos(a)*2.3,pz=z+Math.sin(a)*2.3,y=groundY(px,pz);box(staticData,px,y+.42,pz,1.1,.82,.68,0x91876c,a);}
  }
  for(let i=0;i<22;i++){
    const x=(rng()-.5)*125,z=(rng()-.5)*125;if(Math.hypot(x,z)>78)continue;
    if(obstacleList.some(o=>Math.abs(x-o.x)<o.w/2+2&&Math.abs(z-o.z)<o.d/2+2))continue;
    const y=groundY(x,z);box(staticData,x,y+.5,z,.9,1,.9,0x76583d,rng()*Math.PI);
  }
  // dock on east coast
  for(let i=0;i<8;i++)box(staticData,69+i*1.5,-.12,9,1.5,.3,8,0x6e5842);
}
buildWorld();
const staticArray=new Float32Array(staticData);
bindBuffer(staticBuffer,staticArray);
gl.bufferData(gl.ARRAY_BUFFER,staticArray,gl.STATIC_DRAW);

const MAP_SIZE=90;
const player={x:0,z:67,yaw:0,pitch:-.07,vy:0,grounded:true,hp:100,armor:50,ammo:30,reserve:150,shotgunAmmo:6,shotgunReserve:36,weapon:0,reload:0,fireCd:0,elapsed:0,kills:0,zone:73,zoneDamage:0,walk:0,stamina:100};
const WEAPONS=[
  {name:'ASSAULT RIFLE',code:'AR-07',meta:'5.56 NATO · AUTO',mag:30,reload:1.55,rate:.115,range:70,spread:1.25,damage:27,pellets:1},
  {name:'COMBAT SHOTGUN',code:'SG-12',meta:'12 GAUGE · 6 PELLETS',mag:6,reload:1.9,rate:.72,range:29,spread:3.35,damage:9,pellets:6}
];
const pickups=[];
const bots=[];
const botColors=[0x8b5142,0x4f7180,0x9b7846,0x596c4f,0x805a78,0x4b7771,0x958a60,0x6c627d,0x9a5844];
const keys=new Set();
const touchMove={x:0,y:0};
let gameState='menu',last=0,frameCount=0,shotHold=false,toastUntil=0,damageFlashUntil=0,cam=[0,5,80],cameraPos=[0,5,80],cameraTarget=[0,1,60],lastHud=0;
let viewProj=perspective(Math.PI/3,window.innerWidth/window.innerHeight,.1,260);
let dynamicCount=0;
function spawnBots(){bots.length=0;const rng=seeded(44129);for(let i=0;i<9;i++){const a=(i/9)*Math.PI*2+.35,r=36+rng()*29;bots.push({id:i,x:Math.cos(a)*r,z:Math.sin(a)*r,yaw:0,hp:100,maxHp:100,alive:true,armor:20+Math.floor(rng()*35),speed:2.3+rng()*1.25,cooldown:rng()*1.8,think:1+rng()*2,strafe:i%2?1:-1,phase:rng()*10,color:botColors[i],hit:0});}}
function blocked(x,z,rad=.65){if(Math.hypot(x,z)>80-rad)return true;for(const o of obstacleList){const dx=x-o.x,dz=z-o.z;if(Math.abs(dx)<o.w/2+rad&&Math.abs(dz)<o.d/2+rad)return true;}return false;}
function activeWeapon(){return WEAPONS[player.weapon]||WEAPONS[0];}
function weaponAmmo(){return player.weapon===0?player.ammo:player.shotgunAmmo;}
function weaponReserve(){return player.weapon===0?player.reserve:player.shotgunReserve;}
function setWeaponAmmo(v){if(player.weapon===0)player.ammo=v;else player.shotgunAmmo=v;}
function setWeaponReserve(v){if(player.weapon===0)player.reserve=v;else player.shotgunReserve=v;}
function spawnPickup(type,x,z){pickups.push({type,x,z,phase:Math.random()*6.28,alive:true});}
function spawnLoot(){
  pickups.length=0;
  const drops=[['med',-10,17],['armor',19,-8],['ammo',-39,8],['ammo',35,-27],['med',-1,-37],['armor',43,20],['ammo',-52,-25],['med',15,48],['ammo',-18,35],['armor',58,-8],['med',-31,45],['ammo',27,49]];
  for(const [type,x,z] of drops)spawnPickup(type,x,z);
}
function switchWeapon(index){if(gameState!=='playing'||player.reload>0)return;const next=(index===undefined?(player.weapon+1)%WEAPONS.length:index);if(next<0||next>=WEAPONS.length||next===player.weapon)return;player.weapon=next;toast('EQUIPPED '+activeWeapon().name);updateHud(true);}
function spawnPlayer(){player.x=0;player.z=67;player.yaw=Math.PI;player.pitch=-.07;player.vy=0;player.grounded=true;player.hp=100;player.armor=50;player.ammo=30;player.reserve=150;player.shotgunAmmo=6;player.shotgunReserve=36;player.weapon=0;player.reload=0;player.fireCd=0;player.elapsed=0;player.kills=0;player.zone=73;player.zoneDamage=0;player.walk=0;player.stamina=100;spawnLoot();}
function toast(message){ui.toast.textContent=message;ui.toast.classList.add('show');toastUntil=performance.now()+1500;}
function startGame(lock=true){spawnPlayer();spawnBots();gameState='playing';ui.start.classList.add('hidden');ui.pause.classList.add('hidden');ui.end.classList.add('hidden');ui.hud.classList.remove('hidden');shotHold=false;player.fireHeld=false;touchMove.x=0;touchMove.y=0;keys.clear();if(lock&&canvas.requestPointerLock){try{canvas.requestPointerLock();}catch(e){}}playSound('island-ambience',.20,true);toast('MISSION ACTIVE — ELIMINATE ALL RIVALS');updateHud(true);}
function pauseGame(){if(gameState!=='playing')return;gameState='paused';shotHold=false;if(audioPool['island-ambience'])audioPool['island-ambience'].pause();ui.pause.classList.remove('hidden');if(document.pointerLockElement===canvas)document.exitPointerLock();}
function resumeGame(){if(gameState!=='paused')return;gameState='playing';playSound('island-ambience',.20,true);ui.pause.classList.add('hidden');if(canvas.requestPointerLock)try{canvas.requestPointerLock();}catch(e){}}
function finishGame(win){if(gameState!=='playing')return;gameState=win?'won':'lost';shotHold=false;if(document.pointerLockElement===canvas)document.exitPointerLock();ui.endTitle.textContent=win?'BOOYAH!':'ELIMINATED';ui.endCopy.textContent=win?'You own the island. Every rival is down.':'You were outplayed. Redeploy and fight again.';ui.finalKills.textContent=String(player.kills).padStart(2,'0');ui.end.classList.remove('hidden');}
function reload(){const w=activeWeapon(),ammo=weaponAmmo(),reserve=weaponReserve();if(gameState!=='playing'||player.reload>0||ammo>=w.mag||reserve<=0)return;player.reload=w.reload;ui.reload.classList.add('show');}
function damagePlayer(amount){let d=amount;if(player.armor>0){const absorb=Math.min(player.armor,d*.62);player.armor-=absorb;d-=absorb;}player.hp=Math.max(0,player.hp-d);ui.hurt.style.opacity='.95';damageFlashUntil=performance.now()+180;if(player.hp<=0)finishGame(false);}
function fire(){
  if(gameState!=='playing'||player.reload>0||player.fireCd>0)return;
  const w=activeWeapon();if(weaponAmmo()<=0){reload();return;}
  setWeaponAmmo(weaponAmmo()-1);player.fireCd=w.rate;
  const fx=Math.sin(player.yaw)*Math.cos(player.pitch),fz=-Math.cos(player.yaw)*Math.cos(player.pitch),fy=Math.sin(player.pitch);
  let target=null,best=w.range,bestSide=Infinity;
  for(const b of bots){if(!b.alive)continue;const dx=b.x-player.x,dz=b.z-player.z,along=dx*fx+dz*fz,side=Math.abs(dx*fz-dz*fx);const width=w.spread+(w.name.includes('SHOTGUN')?along*.035:along*.018);if(along>1&&along<best&&side<width){target=b;best=along;bestSide=side;}}
  const start=[player.x+fx*.65,groundY(player.x,player.z)+1.55,player.z+fz*.65];
  let end=[player.x+fx*w.range,start[1]+fy*w.range,player.z+fz*w.range];
  if(target){end=[target.x,groundY(target.x,target.z)+1.25,target.z];
    let dealt=w.damage*(w.pellets===1?(.88+Math.random()*.24):Math.max(1,Math.round(w.pellets*(1-bestSide/(w.spread+best*.035)))));
    const absorbed=Math.min(target.armor||0,dealt*.45);target.armor=Math.max(0,(target.armor||0)-absorbed);target.hp-=dealt-absorbed;target.hit=.18;
    playSound('hit-confirm',.35);ui.hit.classList.remove('on');void ui.hit.offsetWidth;ui.hit.classList.add('on');
    if(target.hp<=0){target.hp=0;target.alive=false;player.kills++;if(Math.random()<.55)spawnPickup(Math.random()<.45?'ammo':Math.random()<.5?'med':'armor',target.x+(Math.random()-.5)*2,target.z+(Math.random()-.5)*2);toast('RIVAL ELIMINATED · LOOT DROPPED');if(bots.every(b=>!b.alive))finishGame(true);}
  }
  tracerLines.push({a:start,b:end,life:w.pellets===1?.11:.16});playSound('rifle-shot',w.pellets===1?.22:.38);spawnSpark(player.x+fx*1.05,groundY(player.x,player.z)+1.5,player.z+fz*1.05);
  if(weaponAmmo()===0)toast('MAGAZINE EMPTY — RELOAD');
}
function collectPickups(){
  for(const item of pickups){if(!item.alive)continue;if(Math.hypot(item.x-player.x,item.z-player.z)>2.25)continue;
    if(item.type==='med'){const before=player.hp;player.hp=Math.min(100,player.hp+35);if(player.hp===before)continue;toast('MEDKIT +'+Math.round(player.hp-before)+' HEALTH');}
    else if(item.type==='armor'){const before=player.armor;player.armor=Math.min(50,player.armor+25);if(player.armor===before)continue;toast('ARMOR +'+Math.round(player.armor-before));}
    else{const ar=Math.min(240-player.reserve,45),sg=Math.min(60-player.shotgunReserve,12);if(ar<=0&&sg<=0)continue;player.reserve+=ar;player.shotgunReserve+=sg;toast('AMMO RESUPPLIED');}
    item.alive=false;
  }
}
function spawnSpark(x,y,z){particles.push({x,y,z,vx:(Math.random()-.5)*2,vy:1+Math.random()*2,vz:(Math.random()-.5)*2,life:.34});}
const particles=[],tracerLines=[];
function updateBots(dt){
  for(const b of bots){if(!b.alive)continue;const dx=player.x-b.x,dz=player.z-b.z,dist=Math.hypot(dx,dz)||1;b.yaw=Math.atan2(dx,-dz);b.cooldown-=dt;b.think-=dt;if(b.think<=0){b.strafe=Math.random()<.5?-1:1;b.think=1.3+Math.random()*2.4;}
    let move=dist>15?1:dist<6?-.5:.08;if(b.hp<34)move=-.62;else if(player.hp<35&&dist>7)move=1.15;const sx=Math.cos(b.yaw)*b.strafe,sz=Math.sin(b.yaw)*b.strafe;
    let nx=b.x+(dx/dist*move+sx*.58)*b.speed*dt,nz=b.z+(dz/dist*move+sz*.58)*b.speed*dt;
    if(!blocked(nx,b.z,.55))b.x=nx;if(!blocked(b.x,nz,.55))b.z=nz;
    if(dist<34&&b.cooldown<=0){const accuracy=clamp(.56-dist*.009,.18,.48);if(Math.random()<accuracy)damagePlayer(4+Math.random()*7);b.cooldown=(dist<13?.72:1.05)+Math.random()*.85;spawnSpark(player.x,groundY(player.x,player.z)+1.4,player.z);}
    if(Math.hypot(b.x,b.z)>player.zone&&player.elapsed>22){b.hp-=dt*5.5;if(b.hp<=0)b.alive=false;}
    b.hit=Math.max(0,b.hit-dt);
  }
}
function update(dt){
  if(gameState!=='playing')return;
  player.elapsed+=dt;player.fireCd=Math.max(0,player.fireCd-dt);
  if(player.reload>0){player.reload-=dt;if(player.reload<=0){const w=activeWeapon(),take=Math.min(w.mag-weaponAmmo(),weaponReserve());setWeaponAmmo(weaponAmmo()+take);setWeaponReserve(weaponReserve()-take);ui.reload.classList.remove('show');playSound('reload-click',.4);toast('MAGAZINE RELOADED');}}
  const f=keys.has('KeyW')||keys.has('ArrowUp')?1:0,b=keys.has('KeyS')||keys.has('ArrowDown')?1:0,l=keys.has('KeyA')||keys.has('ArrowLeft')?1:0,r=keys.has('KeyD')||keys.has('ArrowRight')?1:0;
  let forward=f-b+touchMove.y,side=r-l+touchMove.x;const len=Math.hypot(forward,side)||1;forward/=len;side/=len;
  const wantsSprint=keys.has('ShiftLeft')||keys.has('ShiftRight'),fast=wantsSprint&&player.stamina>3&&Math.abs(forward)+Math.abs(side)>.2;player.stamina=clamp(player.stamina+(fast?-28:18)*dt,0,100);const speed=fast?10.5:6.5,fx=Math.sin(player.yaw),fz=-Math.cos(player.yaw),rx=Math.cos(player.yaw),rz=Math.sin(player.yaw);
  const mx=(fx*forward+rx*side)*speed*dt,mz=(fz*forward+rz*side)*speed*dt;
  if(!blocked(player.x+mx,player.z,.66))player.x+=mx;if(!blocked(player.x,player.z+mz,.66))player.z+=mz;
  if(forward||side)player.walk+=dt*(fast?12:8);
  if(!player.grounded){player.vy-=19*dt;player.jumpY+=player.vy*dt;if(player.jumpY<=0){player.jumpY=0;player.grounded=true;player.vy=0;}}
  if(player.fireHeld&&player.fireCd<=0)fire();
  const shrinkStart=35,shrinkDuration=190,t=clamp((player.elapsed-shrinkStart)/shrinkDuration,0,1);player.zone=73-51*(t*t*(3-2*t));
  if(player.elapsed>shrinkStart&&Math.hypot(player.x,player.z)>player.zone){player.zoneDamage+=dt;if(player.zoneDamage>.65){player.zoneDamage=0;damagePlayer(3.2);toast('RETURN TO THE SAFE ZONE');}}else player.zoneDamage=0;
  updateBots(dt);collectPickups();
  for(let i=tracerLines.length-1;i>=0;i--){tracerLines[i].life-=dt;if(tracerLines[i].life<=0)tracerLines.splice(i,1);}
  for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;p.vy-=5*dt;if(p.life<=0)particles.splice(i,1);}
  if(bots.every(b=>!b.alive)&&gameState==='playing')finishGame(true);
}
player.jumpY=0;player.fireHeld=false;
function transformActor(x,y,z,yaw,lx,ly,lz){return rotatePoint(lx,ly,lz,x,y,z,yaw);}
function actorBox(out,actor,lx,ly,lz,w,h,d,col,yawOffset=0){const p=transformActor(actor.x,actor.baseY,lz===Infinity?0:actor.z,actor.yaw,lx,ly,lz);box(out,p[0],p[1],p[2],w,h,d,col,actor.yaw+yawOffset);}
function buildActor(out,actor,isPlayer=false){
  const g=groundY(actor.x,actor.z)+(isPlayer?player.jumpY:0),yaw=actor.yaw,step=Math.sin(isPlayer?player.walk:actor.phase+(player.elapsed*2.8))*.1;
  const base={x:actor.x,y:g,z:actor.z,yaw};
  const P=(lx,ly,lz)=>transformActor(base.x,g,base.z,yaw,lx,ly,lz);
  const B=(lx,ly,lz,w,h,d,c,ang=0)=>{const p=P(lx,ly,lz);box(out,p[0],p[1],p[2],w,h,d,c,yaw+ang);};
  const S=(lx,ly,lz,rx,ry,rz,c)=>{const p=P(lx,ly,lz);sphere(out,p[0],p[1],p[2],rx,ry,rz,c,8,5);};
  const C=(lx,ly,lz,r,h,c)=>{const p=P(lx,ly,lz);cylinder(out,p[0],p[1],p[2],r,h,c,7);};
  const pants=isPlayer?0x35453d:0x343b3b,shirt=isPlayer?0x586a4c:actor.color,gear=isPlayer?0x27352d:0x303b3a,skin=0xb88868;
  B(-.19,.48-step,0,.22,.83,.28,pants,step*1.5);B(.19,.48+step,0,.22,.83,.28,pants,-step*1.5);
  B(-.19,.09,-.02,.25,.16,.39,0x232a26);B(.19,.09,-.02,.25,.16,.39,0x232a26);
  B(0,1.19,0,.57,.72,.34,shirt);B(0,1.2,-.195,.48,.54,.08,gear);
  B(0,1.02,-.25,.42,.1,.08,0x9c8d57);
  B(-.38,1.24,-.01,.18,.62,.21,shirt,-.12);B(.38,1.24,-.01,.18,.62,.21,shirt,.12);
  B(-.39,.91,-.08,.17,.23,.18,skin);B(.39,.91,-.08,.17,.23,.18,skin);
  S(0,1.84,0,.22,.24,.22,skin);S(0,1.99,0,.25,.17,.24,isPlayer?0x3f4d3c:0x444e46);
  B(0,1.71,-.11,.38,.08,.26,isPlayer?0x343f31:0x2d3836);
  B(-.24,1.35,.16,.25,.4,.25,0x465749); // pack
  // rifle held across chest, barrel directed forward (-Z local)
  B(.34,1.16,-.48,.12,.13,.83,0x222a28,-.16);B(.34,1.27,-.66,.07,.06,.56,0x101716,-.16);
  B(.34,1.08,-.31,.14,.26,.18,0x353e3b,-.16);B(.31,1.22,-.18,.08,.08,.18,0x5b604b,-.16);
  // shoulder and knee pads
  S(-.38,1.48,-.02,.13,.12,.15,0x59674e);S(.38,1.48,-.02,.13,.12,.15,0x59674e);
  B(0,1.4,-.19,.11,.11,.035,0xb1a56e);
  if(!isPlayer){
    // visible health strip above the bot's head
    const p=P(0,2.48,0),w=.78,h=.075;box(out,p[0],p[1],p[2],w,h,.055,0x1c2422);box(out,p[0]-(1-actor.hp/100)*w/2,p[1]+.005,p[2]-.032,w*actor.hp/100,.045,.02,0x9bdb61);
  }
}
function addLine(out,a,b,col){const c=color(col);for(const p of [a,b])out.push(p[0],p[1],p[2],0,1,0,c[0],c[1],c[2]);}
function drawLines(arr,mode=gl.LINES){if(!arr.length)return;const data=new Float32Array(arr);bindBuffer(lineBuffer,data);gl.drawArrays(mode,0,data.length/9);}
function buildDynamic(){
  const out=[];buildActor(out,player,true);for(const b of bots)if(b.alive)buildActor(out,b,false);
  for(const item of pickups){if(!item.alive)continue;const y=groundY(item.x,item.z)+.18+Math.sin(player.elapsed*2.4+item.phase)*.08;const c=item.type==='med'?0x75d26b:item.type==='armor'?0x73c6e1:0xe7bd57; cylinder(out,item.x,y,item.z,.46,.22,c,8);box(out,item.x,y+.28,item.z,.52,.38,.52,c);box(out,item.x,y+.51,item.z,.15,.08,.62,0xf0f2df);box(out,item.x,y+.51,item.z,.62,.08,.15,0xf0f2df);
  }
  for(const p of particles){sphere(out,p.x,p.y,p.z,.07,.07,.07,0xe4dc86,5,3);}
  return new Float32Array(out);
}
function buildRingLines(){const out=[],n=150;for(let i=0;i<n;i++){const a=i*2*Math.PI/n,b=(i+1)*2*Math.PI/n,r=player.zone;const p=[Math.cos(a)*r,groundY(Math.cos(a)*r,Math.sin(a)*r)+.22,Math.sin(a)*r],q=[Math.cos(b)*r,groundY(Math.cos(b)*r,Math.sin(b)*r)+.22,Math.sin(b)*r];addLine(out,p,q,player.elapsed>35?0xe2eaa3:0x9fe8b5);}return out;}
function buildTracers(){const out=[];for(const t of tracerLines)addLine(out,t.a,t.b,0xffed9a);return out;}
let drawFrames=0;
const audioPool = {};
function playSound(name, volume=.42, loop=false) {
  if (typeof Audio === 'undefined') return;
  try {
    if (loop) {
      if (!audioPool[name]) { audioPool[name] = new Audio('assets/' + name + '.wav'); audioPool[name].loop = true; }
      audioPool[name].volume = volume;
      if (audioPool[name].paused) audioPool[name].play().catch(()=>{});
    } else {
      const a = new Audio('assets/' + name + '.wav'); a.volume = volume; a.play().catch(()=>{});
    }
  } catch (_) {}
}
function render(){
  const w=canvas.clientWidth,h=canvas.clientHeight,dpr=Math.min(1.65,window.devicePixelRatio||1),rw=Math.max(1,Math.floor(w*dpr)),rh=Math.max(1,Math.floor(h*dpr));
  if(canvas.width!==rw||canvas.height!==rh){canvas.width=rw;canvas.height=rh;gl.viewport(0,0,rw,rh);viewProj=perspective(Math.PI/3,rw/rh,.1,260);}
  const fx=Math.sin(player.yaw),fz=-Math.cos(player.yaw),target=[player.x+fx*5,groundY(player.x,player.z)+2.1+Math.sin(player.pitch)*8,player.z+fz*5];
  const desired=[player.x-fx*8,groundY(player.x,player.z)+5.0,player.z-fz*8];
  const smooth=.09;cameraPos[0]=lerp(cameraPos[0],desired[0],smooth);cameraPos[1]=lerp(cameraPos[1],desired[1],smooth);cameraPos[2]=lerp(cameraPos[2],desired[2],smooth);
  // Avoid camera clipping through the ground when following over a hill
  cameraPos[1]=Math.max(cameraPos[1],groundY(cameraPos[0],cameraPos[2])+1.2);
  const view=lookAt(cameraPos,target),vp=multiply(viewProj,view);
  gl.useProgram(program);gl.uniformMatrix4fv(loc.vp,false,vp);gl.uniform3f(loc.camera,cameraPos[0],cameraPos[1],cameraPos[2]);gl.uniform3f(loc.fog,.45,.59,.61);
  gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.disable(gl.CULL_FACE);gl.clearColor(.42,.62,.68,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
  bindAttributes(staticBuffer);gl.drawArrays(gl.TRIANGLES,0,staticArray.length/9);
  const dynamic=buildDynamic();if(dynamic.length){bindBuffer(dynamicBuffer,dynamic);gl.drawArrays(gl.TRIANGLES,0,dynamic.length/9);}
  gl.depthMask(false);drawLines(buildRingLines());drawLines(buildTracers());gl.depthMask(true);
  drawFrames++;
}
function updateHud(force=false){const now=performance.now();if(!force&&now-lastHud<100)return;lastHud=now;
  ui.alive.textContent=String(bots.filter(b=>b.alive).length+1).padStart(2,'0');ui.kills.textContent=String(player.kills).padStart(2,'0');
  const sec=Math.floor(player.elapsed),mm=String(Math.floor(sec/60)).padStart(2,'0'),ss=String(sec%60).padStart(2,'0');ui.timer.textContent=mm+':'+ss;
  ui.hpLabel.textContent=Math.ceil(player.hp);ui.hpBar.style.width=player.hp+'%';ui.armorLabel.textContent=Math.ceil(player.armor);ui.armorBar.style.width=(player.armor/50*100)+'%';
  ui.ammo.textContent=String(weaponAmmo()).padStart(2,'0');ui.reserve.textContent=String(weaponReserve()).padStart(3,'0');ui.staminaBar.style.width=player.stamina+'%';const weapon=activeWeapon();ui.weaponName.textContent=weapon.name;ui.weaponCode.textContent=weapon.code;ui.weaponMeta.textContent=weapon.meta;
  const danger=player.elapsed>35&&Math.hypot(player.x,player.z)>player.zone;ui.zone.classList.toggle('danger',danger);ui.zone.querySelector('span').textContent=danger?'OUTSIDE SAFE ZONE':('ZONE '+Math.round(player.zone)+'M');
  drawMap();
}
function drawMap(){const c=ui.map.getContext('2d'),w=ui.map.width,h=ui.map.height;c.clearRect(0,0,w,h);c.fillStyle='#243d38';c.fillRect(0,0,w,h);c.save();c.translate(w/2,h/2);c.scale(w/180,-h/180);c.fillStyle='#788960';c.beginPath();c.arc(0,0,MAP_SIZE,0,Math.PI*2);c.fill();c.strokeStyle='rgba(218,229,189,.22)';c.lineWidth=1.1;c.stroke();
  c.strokeStyle='rgba(45,53,47,.55)';c.lineWidth=5;c.beginPath();c.moveTo(0,-82);c.lineTo(0,82);c.moveTo(-75,7);c.lineTo(75,7);c.stroke();
  c.strokeStyle='#d9f4ab';c.lineWidth=1.5;c.beginPath();c.arc(0,0,player.zone,0,Math.PI*2);c.stroke();
  for(const b of bots)if(b.alive){c.fillStyle='#f17f61';c.beginPath();c.arc(b.x,b.z,2.5,0,Math.PI*2);c.fill();}
  for(const item of pickups)if(item.alive){c.fillStyle=item.type==='med'?'#8ae07d':item.type==='armor'?'#83d4ef':'#f0ca68';c.fillRect(item.x-1.35,item.z-1.35,2.7,2.7);}
  c.fillStyle='#d8fb76';c.beginPath();c.arc(player.x,player.z,3.3,0,Math.PI*2);c.fill();c.strokeStyle='#d8fb76';c.lineWidth=1.5;c.beginPath();c.moveTo(player.x,player.z);c.lineTo(player.x+Math.sin(player.yaw)*8,player.z-Math.cos(player.yaw)*8);c.stroke();c.restore();}
function frame(now){const dt=Math.min(.05,(now-last)/1000||0);last=now;if(gameState==='playing')update(dt);render();if(gameState==='playing')updateHud();if(toastUntil&&now>toastUntil){ui.toast.classList.remove('show');toastUntil=0;}if(damageFlashUntil&&now>damageFlashUntil){ui.hurt.style.opacity='0';damageFlashUntil=0;}requestAnimationFrame(frame);}

ui.deploy.addEventListener('click',()=>startGame(true));ui.resume.addEventListener('click',resumeGame);ui.restart.addEventListener('click',()=>startGame(true));ui.again.addEventListener('click',()=>startGame(true));
window.addEventListener('keydown',e=>{if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();keys.add(e.code);if(e.code==='Escape'&&gameState==='playing')pauseGame();if(e.code==='KeyR')reload();if(e.code==='Digit1')switchWeapon(0);if(e.code==='Digit2')switchWeapon(1);if(e.code==='KeyQ')switchWeapon();if(e.code==='KeyE')collectPickups();if(e.code==='Space'&&gameState==='playing'&&player.grounded){player.vy=7.2;player.grounded=false;} });
window.addEventListener('keyup',e=>keys.delete(e.code));
canvas.addEventListener('mousedown',e=>{if(e.button!==0||gameState!=='playing')return;if(document.pointerLockElement!==canvas&&canvas.requestPointerLock){try{canvas.requestPointerLock();}catch(err){}}player.fireHeld=true;fire();});
window.addEventListener('mouseup',e=>{if(e.button===0)player.fireHeld=false;});
canvas.addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('pointerlockchange',()=>{if(document.pointerLockElement!==canvas&&gameState==='playing'&&performance.now()>1000){/* losing lock does not pause; Escape is handled explicitly */}});
window.addEventListener('mousemove',e=>{if(document.pointerLockElement===canvas&&gameState==='playing'){player.yaw+=e.movementX*.0026;player.pitch=clamp(player.pitch-e.movementY*.0018,-.48,.42);}});
window.addEventListener('resize',()=>{viewProj=perspective(Math.PI/3,window.innerWidth/window.innerHeight,.1,260);});

// Touch-first controls: left virtual stick for movement, right drag for camera,
// and large action buttons for firing, jumping, reloading and swapping weapons.
const moveStick=$('move-stick'),stickKnob=$('stick-knob'),aimPad=$('aim-pad');
let stickPointer=null,aimPointer=null,aimLast=null;
function updateStick(e){const r=moveStick.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,dx=e.clientX-cx,dy=e.clientY-cy,max=Math.min(r.width,r.height)*.34,len=Math.hypot(dx,dy)||1,k=Math.min(1,max/len);touchMove.x=dx/max*k;touchMove.y=-dy/max*k;stickKnob.style.transform=`translate(${touchMove.x*max}px, ${-touchMove.y*max}px)`;}
moveStick.addEventListener('pointerdown',e=>{stickPointer=e.pointerId;moveStick.setPointerCapture?.(e.pointerId);updateStick(e);});
moveStick.addEventListener('pointermove',e=>{if(stickPointer===e.pointerId)updateStick(e);});
function releaseStick(e){if(stickPointer===e.pointerId){stickPointer=null;touchMove.x=0;touchMove.y=0;stickKnob.style.transform='translate(0,0)';}}
moveStick.addEventListener('pointerup',releaseStick);moveStick.addEventListener('pointercancel',releaseStick);
aimPad.addEventListener('pointerdown',e=>{aimPointer=e.pointerId;aimLast={x:e.clientX,y:e.clientY};aimPad.setPointerCapture?.(e.pointerId);});
aimPad.addEventListener('pointermove',e=>{if(aimPointer!==e.pointerId||!aimLast||gameState!=='playing')return;const dx=e.clientX-aimLast.x,dy=e.clientY-aimLast.y;player.yaw+=dx*.008;player.pitch=clamp(player.pitch-dy*.006,-.48,.42);aimLast={x:e.clientX,y:e.clientY};});
function releaseAim(e){if(aimPointer===e.pointerId){aimPointer=null;aimLast=null;}}
aimPad.addEventListener('pointerup',releaseAim);aimPad.addEventListener('pointercancel',releaseAim);
const bindTouchButton=(id,down,up)=>{const el=$(id);el.addEventListener('pointerdown',e=>{e.preventDefault();el.setPointerCapture?.(e.pointerId);down(e);});el.addEventListener('pointerup',e=>{e.preventDefault();up?.(e);});el.addEventListener('pointercancel',e=>up?.(e));};
bindTouchButton('touch-fire',()=>{if(gameState==='playing'){player.fireHeld=true;fire();}},()=>{player.fireHeld=false;});
bindTouchButton('touch-jump',()=>{if(gameState==='playing'&&player.grounded){player.vy=7.2;player.grounded=false;}});
bindTouchButton('touch-reload',()=>reload());
bindTouchButton('touch-swap',()=>switchWeapon());

// Exposed deterministic hooks power the included browser QA suite.
window.__DROPZONE_TEST__={
  state:()=>gameState,
  start:()=>startGame(false),
  update:(dt)=>update(dt),
  setKey:(code,on)=>on?keys.add(code):keys.delete(code),
  positionBot:(i,x,z)=>{bots.forEach((b,j)=>{if(j!==i){b.x=72+j;b.z=72-j;}});const b=bots[i];if(b){b.x=x;b.z=z;b.hp=100;b.alive=true;}},
  fire:()=>fire(),
  reload:()=>reload(),switchWeapon:(i)=>switchWeapon(i),collect:()=>collectPickups(),addPickup:(type,x,z)=>spawnPickup(type,x,z),pickups:()=>pickups.filter(p=>p.alive).length,
  player:()=>({x:player.x,z:player.z,hp:player.hp,armor:player.armor,ammo:weaponAmmo(),reserve:weaponReserve(),rifleAmmo:player.ammo,shotgunAmmo:player.shotgunAmmo,weapon:player.weapon,stamina:player.stamina,zone:player.zone,elapsed:player.elapsed,kills:player.kills}),
  bot:(i)=>bots[i]?({x:bots[i].x,z:bots[i].z,hp:bots[i].hp,armor:bots[i].armor,alive:bots[i].alive}):null,
  damage:(n)=>damagePlayer(n),setPlayer:(x,z,yaw=Math.PI)=>{player.x=x;player.z=z;player.yaw=yaw;},
  setElapsed:t=>player.elapsed=t,
  setReload:t=>player.reload=t,
  forceVictory:()=>{for(const b of bots)b.alive=false;finishGame(true);},
  forceDefeat:()=>{finishGame(false);},
  restart:()=>startGame(false),
  glVersion:()=>gl.getParameter(gl.VERSION),
  frameCount:()=>drawFrames,
  meshVertices:()=>staticArray.length/9
};

if(new URLSearchParams(location.search).has('qa')){
  setTimeout(()=>{
    const api=window.__DROPZONE_TEST__,results=[];const check=(name,fn)=>{try{const v=fn();if(v)results.push('PASS — '+name);else results.push('FAIL — '+name);}catch(e){results.push('FAIL — '+name+' ('+e.message+')');}};
    check('WebGL renderer initialized and rendered frames',()=>api.glVersion().includes('WebGL')&&api.frameCount()>0&&api.meshVertices()>10000);
    api.start();
    check('Deployment creates player and nine living rivals',()=>api.state()==='playing'&&api.player().hp===100&&bots.length===9&&bots.every(b=>b.alive));
    const before=api.player();api.setKey('KeyW',true);api.update(.5);api.setKey('KeyW',false);const after=api.player();
    check('WASD movement changes player world position',()=>Math.hypot(after.x-before.x,after.z-before.z)>1);
    const p=api.player();api.positionBot(0,p.x,p.z+7);api.fire();const hit=api.bot(0);const fired=api.player();api.setReload(.02);api.update(.03);
    check('Rifle shot damages target and consumes ammo; reload refills magazine',()=>hit.hp<100&&fired.ammo===29&&api.player().ammo===30);
    api.setElapsed(210);const old=api.player().zone;api.update(.02);const newZone=api.player().zone;api.forceVictory();
    const victory=api.state()==='won';api.restart();api.forceDefeat();const defeat=api.state()==='lost';
    check('Safe zone contracts; victory, defeat, and restart states work',()=>newZone<73&&victory&&api.state()==='lost'&&defeat);
    const failed=results.some(s=>s.startsWith('FAIL'));
    const pre=document.createElement('pre');pre.id='qa-report';pre.textContent=results.join('\n')+'\n\nRESULT: '+results.filter(s=>s.startsWith('PASS')).length+'/5 PASSED';document.body.appendChild(pre);
    document.documentElement.dataset.qa=failed?'fail':'pass';document.documentElement.dataset.qaCount=String(results.filter(s=>s.startsWith('PASS')).length);
  },450);
}
requestAnimationFrame(frame);
})();
