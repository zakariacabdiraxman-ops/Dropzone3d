# DROPZONE: ISLAND CLASH — Upgrade 1.1

An original, third-person browser battle-royale prototype built with WebGL 1, HTML, CSS, and vanilla JavaScript. The 3D scene is rendered by the GPU and its island, buildings, characters, props, pickups, and weapon geometry are generated locally at runtime. No engine installation, CDN, or external model download is required.

## Run

1. Extract the ZIP into a folder.
2. Open `index.html` in a current Chrome or Edge browser.
3. Select **DEPLOY TO ISLAND**. On desktop, allow mouse capture for aiming.

If your browser restricts local-file audio, open a terminal in this folder and run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Desktop controls

| Input | Action |
|---|---|
| W / A / S / D | Move |
| Mouse | Aim / rotate view |
| Left mouse button | Fire current weapon |
| 1 / 2 or Q | Switch weapon |
| R | Reload current weapon |
| E | Collect nearby supplies |
| Shift | Sprint (uses stamina) |
| Space | Jump |
| Esc | Pause |

## Mobile / touch controls

The mobile layout shows a virtual movement stick on the left, a drag-to-aim pad on the right, and touch buttons for firing, jumping, reloading, and switching weapons. Pickups are collected automatically when you walk close to them.

## Upgrade 1.1 gameplay

- Two independent weapons: AR-07 automatic rifle and SG-12 combat shotgun, each with its own magazine, reserve ammunition, firing cadence, range, and reload time
- Twelve initial supply pickups: medkits, armor plates, and ammunition crates; defeated rivals can also drop supplies
- Health and armor pickup effects, with caps so supplies are not wasted when the relevant resource is full
- Sprint stamina that drains while sprinting and regenerates while walking or standing
- Improved rival pressure and retreat behavior, plus bot armor that reduces incoming damage
- Loot pickups rendered in the 3D world and marked on the tactical map
- Mobile/touch movement, aiming, firing, jumping, weapon switching, and reloading

## Existing battle-royale features

- WebGL island terrain, beach, roads, forest, rocks, buildings, tower, containers, crates, and cover
- Third-person player operative and nine rival AI operatives
- Rifle/shotgun combat, hit feedback, tracers, armor, health, and reload animations
- Shrinking safe zone, tactical minimap, match clock, elimination count, victory/defeat, pause, and restart
- Original generated rifle-shot, hit-confirm, reload-click, and island-ambience audio
- Procedural geometry and original low-poly graphics; no downloaded game assets

## Automated QA

Node.js is only required for the offline QA suite. Run it from this folder:

```bash
node tests/qa-node.js
```

The 8 checks cover WebGL initialization/draw submission using a mocked WebGL context, deployment, keyboard movement and stamina, both weapon systems, reload behavior, pickups, touch-control event wiring, and match state transitions. The mocked WebGL check is not a substitute for a visual test on a real browser/GPU.

## Scope

This is an original single-player browser prototype inspired by the battle-royale genre. It is not the official Free Fire game, does not use Garena assets, and does not implement online multiplayer, matchmaking, or a production-grade physics/animation pipeline.
