DROPZONE: ISLAND CLASH — ANDROID PROJECT

This ZIP is an Android Studio project wrapping the supplied DropZone 3D browser game
inside a native Android WebView. It is NOT itself an APK, and renaming .zip to .apk
will not work.

BUILD THE APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose Open and select the extracted DropZone3D-Android folder.
4. Allow Gradle sync and install Android SDK Platform 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When complete, choose "locate" in the notification. The APK is normally at:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer app-debug.apk to your Android phone and install it. You may need to
   allow installation from that file manager.

PROJECT DETAILS
- App: DropZone: Island Clash
- Package: com.dropzone.islandclash
- Orientation: landscape
- Minimum Android: Android 6.0 (API 23)
- Game files are bundled locally in app/src/main/assets; no network is required.
- JavaScript and WebGL are enabled in the WebView.

NOTE
The supplied game is an original single-player browser prototype. The original
README and QA report are included in app/src/main/assets.
